#ifndef CSC_C_SOLVER_H
#define CSC_C_SOLVER_H

extern "C"{

#ifdef _WIN32
#define LIB_SUFFIX ".dll"
#define LIB_PREFIX ""
#else
#define LIB_SUFFIX ".so"
#define LIB_PREFIX "lib"
#endif

void* csc_solver_new(const char * name,unsigned char sizeof_int, unsigned char sizeof_val, unsigned char real_or_complex,
					size_t nrows, size_t ncols,
					const void *ptr, const void *idx, const void *val,
					void *opt,const char* path_);

int csc_reorder_matrix(void* solver_,const char* path_);

int csc_analyze(void* solver_,const char* path_);

int csc_factorize(void* solver_,const char* path_);

int csc_solve(void* solver_,const char* path_, const void *b, void *x, size_t nrhs = 1, void *opts = 0);

int csc_solver_delete(void* solver_,const char* path_);

}
#endif
