#ifndef CSC_SOLVER_H
#define CSC_SOLVER_H

#include <complex>
#include <stdio.h>
#include <string.h>
#include <csc_c_solver.h>
#include "./type_traits.h"
#include "./csc_c_solver.h"

class csc_base_linear_solver{
public:
	virtual ~csc_base_linear_solver(){};
	virtual int solve(const void *b, void *x, size_t nrhs = 1, void *opts = 0) = 0;
protected:
	void* solver_;
};

//template<typename INT_TYPE,typename VAL_TYPE>
class csc_solver : csc_base_linear_solver {
public:
	template<typename INT_TYPE,typename VAL_TYPE>
	csc_solver(const char* name,
		size_t nrows, size_t ncols,
		const INT_TYPE *ptr, const INT_TYPE *idx, const VAL_TYPE *val,
		void *opts,const char* path = NULL)
	{
		if(!path){
			if(!strcmp(name,"cholmod")){
					path_ = LIB_PREFIX;
					path_ += "csc_cholmod";
					path_ += LIB_SUFFIX;
			}
			if(!strcmp(name,"umfpack")){
					path_ = LIB_PREFIX;
					path_ += "csc_umfpack";
					path_ += LIB_SUFFIX;
			}
			if(!strcmp(name,"taucs")){
					path_ = LIB_PREFIX;
					path_ += "csc_taucs";
					path_ += LIB_SUFFIX;
			}
		}
		else
				path_ = const_cast<char*>(path);
		solver_ = csc_solver_new(name,sizeof(INT_TYPE),size_t(hj::sparse::value_type<VAL_TYPE>::size),hj::sparse::value_type<VAL_TYPE>::type,nrows,ncols,ptr,idx,val,opts,path_.c_str());
		if(!solver_)
			printf("initial error!\n");
	}
	int reorder_matrix(){
		if(solver_){
				if(csc_reorder_matrix(solver_,path_.c_str()) != 0){
						printf("csc_reorder_matrix error!\n");
						return 1;
				}
		}
		else{
			printf("solver is empty!\n");
			return 2;
		}
		return 0;
	}
	int analyze(){
		if(solver_){
			    if(csc_analyze(solver_,path_.c_str()) != 0){
						printf("csc_analyze error!\n");
						return 1;
				}
		}
		else{
			printf("solver is empty!\n");
			return 2;
		}
		return 0;
	}
	int factorize(){
		if(solver_){
				if(csc_factorize(solver_,path_.c_str()) != 0){
						printf("csc_factorize error!\n");
						return 1;
				}
		}
		else{
			printf("solver is empty!\n");
			return 2;
		}
		return 0;
	}
	int solve(const void *b, void *x, size_t nrhs = 1, void *opts = 0){
		if(solver_){
				if(csc_solve(solver_,path_.c_str(),b,x,nrhs,opts) != 0){
						printf("csc_solve error!\n");
						return 1;
			}
		}
		else{
			printf("solver is empty!\n");
			return 2;
		}
		return 0;
	}
	~csc_solver(){
		if(solver_){
				if(csc_solver_delete(solver_,path_.c_str()) != 0){
						printf("csc_solver_delete error!\n");
				}
		}
		else{
			printf("solver is empty!\n");
		}
	}
private:
	const char* name_;
	std::string path_;
};


#endif
