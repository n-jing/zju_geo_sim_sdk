#ifndef _CSC_SY2LTRI_
#define _CSC_SY2LTRI_
#include <stdio.h>
#include <stdlib.h>
#define INT8_T 1
#define INT16_T 2
#define INT32_T 3
#define INT64_T 4

template <typename T>
size_t getLen(T *ptr, T *idx,size_t ptrL);

template <typename T1, typename T2>
void csc_sy2tri(T1 *ptr, T1 *idx, T2 *val, T1 *R_ptr, T1 *R_idx, T2 *R_val, int ptrL);

extern "C"
{
	int convert_low_tri(unsigned char sizeof_int, unsigned char sizeof_val, unsigned char real_or_complex,
		size_t nrows, size_t ncols, 
		const void *ptr, const void *idx, const void *val,
		void **R_ptr,  void **R_idx,  void **R_val);
};
#endif
