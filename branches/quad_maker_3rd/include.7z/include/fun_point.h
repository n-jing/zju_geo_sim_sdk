#ifndef GET_FUN_POINT_H
#define GET_FUN_POINT_H

extern "C"{
#include <gmodule.h>
}
#include <stdio.h>
#include <string.h>

#ifdef _WIN32
	#define LIB_SUFFIX ".dll"
#else
	#define LIB_SUFFIX ".so"
#endif

inline int get_function_point(const char* file_name,const char* fun_name, gpointer *point){
	GModule *module = g_module_open (file_name, G_MODULE_BIND_LAZY);
	if (!module)
	{
		printf("%s\n",g_module_error());
		return 1;
	}
	if (!g_module_symbol (module, fun_name, point))
	{
		g_module_close (module);
		return 2;
	}
	if (point == NULL)
	{
		g_module_close(module);
		return 3;
	}
	return 0;
}
#endif
